// Products page functionality
document.addEventListener('DOMContentLoaded', function() {
    const allProducts = [
        // Kitchen Essentials
        {
            id: 1,
            name: "Premium Kitchen Set",
            price: 89.99,
            image: "https://images.pexels.com/photos/4226769/pexels-photo-4226769.jpeg",
            rating: 4.8,
            category: "kitchen"
        },
        {
            id: 5,
            name: "Stainless Steel Cookware",
            price: 129.99,
            image: "https://images.pexels.com/photos/4226140/pexels-photo-4226140.jpeg",
            rating: 4.9,
            category: "kitchen"
        },
        {
            id: 6,
            name: "Wooden Cutting Board Set",
            price: 34.99,
            image: "https://images.pexels.com/photos/4226924/pexels-photo-4226924.jpeg",
            rating: 4.7,
            category: "kitchen"
        },
        {
            id: 7,
            name: "Kitchen Utensil Holder",
            price: 24.99,
            image: "https://images.pexels.com/photos/4226796/pexels-photo-4226796.jpeg",
            rating: 4.5,
            category: "kitchen"
        },
        {
            id: 8,
            name: "Ceramic Dinnerware",
            price: 67.99,
            image: "https://images.pexels.com/photos/1324803/pexels-photo-1324803.jpeg",
            rating: 4.6,
            category: "kitchen"
        },
        
        // Home Décor
        {
            id: 2,
            name: "Elegant Table Lamp",
            price: 45.99,
            image: "https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg",
            rating: 4.9,
            category: "decor"
        },
        {
            id: 9,
            name: "Modern Wall Art",
            price: 79.99,
            image: "https://images.pexels.com/photos/1579708/pexels-photo-1579708.jpeg",
            rating: 4.8,
            category: "decor"
        },
        {
            id: 10,
            name: "Decorative Vase Set",
            price: 52.99,
            image: "https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg",
            rating: 4.6,
            category: "decor"
        },
        {
            id: 11,
            name: "Throw Pillow Collection",
            price: 39.99,
            image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
            rating: 4.7,
            category: "decor"
        },
        {
            id: 12,
            name: "Scented Candle Set",
            price: 28.99,
            image: "https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg",
            rating: 4.5,
            category: "decor"
        },
        
        // Storage Solutions
        {
            id: 3,
            name: "Storage Basket Set",
            price: 32.99,
            image: "https://images.pexels.com/photos/6394552/pexels-photo-6394552.jpeg",
            rating: 4.7,
            category: "storage"
        },
        {
            id: 13,
            name: "Wooden Storage Boxes",
            price: 48.99,
            image: "https://images.pexels.com/photos/6527052/pexels-photo-6527052.jpeg",
            rating: 4.6,
            category: "storage"
        },
        {
            id: 14,
            name: "Fabric Storage Bins",
            price: 25.99,
            image: "https://images.pexels.com/photos/6394552/pexels-photo-6394552.jpeg",
            rating: 4.4,
            category: "storage"
        },
        {
            id: 15,
            name: "Under-Bed Storage",
            price: 42.99,
            image: "https://images.pexels.com/photos/6527052/pexels-photo-6527052.jpeg",
            rating: 4.5,
            category: "storage"
        },
        
        // Cleaning Supplies
        {
            id: 16,
            name: "Eco-Friendly Cleaning Kit",
            price: 36.99,
            image: "https://images.pexels.com/photos/4107123/pexels-photo-4107123.jpeg",
            rating: 4.8,
            category: "cleaning"
        },
        {
            id: 17,
            name: "Microfiber Cloth Set",
            price: 18.99,
            image: "https://images.pexels.com/photos/4107123/pexels-photo-4107123.jpeg",
            rating: 4.6,
            category: "cleaning"
        },
        {
            id: 18,
            name: "All-Purpose Cleaner",
            price: 12.99,
            image: "https://images.pexels.com/photos/4107123/pexels-photo-4107123.jpeg",
            rating: 4.7,
            category: "cleaning"
        },
        {
            id: 19,
            name: "Cleaning Caddy Organizer",
            price: 29.99,
            image: "https://images.pexels.com/photos/4107123/pexels-photo-4107123.jpeg",
            rating: 4.5,
            category: "cleaning"
        }
    ];

    let filteredProducts = [...allProducts];
    const productsContainer = document.getElementById('all-products');
    const categoryFilter = document.getElementById('category-filter');
    const sortFilter = document.getElementById('sort-filter');

    // Load products on page load
    displayProducts(filteredProducts);

    // Category filter
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            filterAndSortProducts();
        });
    }

    // Sort filter
    if (sortFilter) {
        sortFilter.addEventListener('change', function() {
            filterAndSortProducts();
        });
    }

    // Check for category parameter in URL
    const urlParams = new URLSearchParams(window.location.search);
    const categoryParam = urlParams.get('category');
    if (categoryParam && categoryFilter) {
        categoryFilter.value = categoryParam;
        filterAndSortProducts();
    }

    function filterAndSortProducts() {
        const selectedCategory = categoryFilter ? categoryFilter.value : 'all';
        const selectedSort = sortFilter ? sortFilter.value : 'featured';

        // Filter products
        if (selectedCategory === 'all') {
            filteredProducts = [...allProducts];
        } else {
            filteredProducts = allProducts.filter(product => product.category === selectedCategory);
        }

        // Sort products
        switch (selectedSort) {
            case 'price-low':
                filteredProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-high':
                filteredProducts.sort((a, b) => b.price - a.price);
                break;
            case 'rating':
                filteredProducts.sort((a, b) => b.rating - a.rating);
                break;
            default:
                // Keep original order for featured
                break;
        }

        displayProducts(filteredProducts);
    }

    function displayProducts(products) {
        if (!productsContainer) return;

        if (products.length === 0) {
            productsContainer.innerHTML = `
                <div class="no-products">
                    <p>No products found matching your criteria.</p>
                </div>
            `;
            return;
        }

        productsContainer.innerHTML = products.map(product => `
            <div class="product-card fade-in">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                    <button class="wishlist-btn" aria-label="Add to wishlist">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                        </svg>
                    </button>
                </div>
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-rating">
                        <div class="stars">${generateStars(product.rating)}</div>
                        <span class="rating-text">(${product.rating})</span>
                    </div>
                    <div class="product-footer">
                        <span class="product-price">$${product.price.toFixed(2)}</span>
                        <button class="add-to-cart" data-product-id="${product.id}">Add to Cart</button>
                    </div>
                </div>
            </div>
        `).join('');

        // Re-observe new elements for animations
        productsContainer.querySelectorAll('.fade-in').forEach(el => {
            // Create a new observer for this page if it doesn't exist
            if (!window.productsObserver) {
                window.productsObserver = new IntersectionObserver(function(entries) {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            entry.target.classList.add('visible');
                        }
                    });
                }, {
                    threshold: 0.1,
                    rootMargin: '0px 0px -50px 0px'
                });
            }
            window.productsObserver.observe(el);
        });
    }

    function generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        let starsHTML = '';

        for (let i = 0; i < fullStars; i++) {
            starsHTML += '★';
        }

        if (hasHalfStar) {
            starsHTML += '☆';
        }

        // Fill remaining stars
        const remainingStars = 5 - Math.ceil(rating);
        for (let i = 0; i < remainingStars; i++) {
            starsHTML += '☆';
        }

        return starsHTML;
    }
});